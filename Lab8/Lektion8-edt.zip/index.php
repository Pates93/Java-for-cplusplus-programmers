<?php
function sourceFile( $filename ){
	echo '<pre class="prettyprint">';
	$source = @file_get_contents($filename);
	if( empty($source) )
		echo "Can't find file $filename";
	else{
		echo "// File: $filename<br/><br/>";
		$source = htmlspecialchars($source);
		echo $source;
	}
	echo '</pre>';
}
function sourceFileLine( $filename, $rowmin, $rowmax ){
	$file = @fopen( $filename, "r" );
	if( ! $file )
		return;
	echo '<pre class="prettyprint">';
	echo "// File: $filename<br/>";
	echo "// Line: $rowmin - $rowmax<br/><br/>";
	$line = 1;
	while( ($buffer = fgets($file, 4096)) !== false) {
		if( $line > $rowmax )
			break;
		if( $line >= $rowmin )
			echo htmlspecialchars($buffer);
		$line++;
    }
	echo '</pre>';
}
?>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<!-- Syntax highlighter, highlights all "prettyprint"-classed pre element -->
	<style>
<?php include('highlight.css'); ?>
	</style>
	<script src="https://google-code-prettify.googlecode.com/svn/loader/run_prettify.js"></script>
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<!-- End of highlighter -->


<!-- Replaces tab with spaces -->
	<script>
	$( document ).ready(function() {
		$('.prettyprint').html(function() {
			//return this.innerHTML.replace(/\t/g, '&nbsp;&nbsp;&nbsp;&nbsp;');
		});
		//prettyPrint();
		$('.sourcecode').html(function() {
			alert( $(this).text() );
		});
	});
	</script>

</head>
<body>

<h1>GUI med Swing</h1>

<h2>EDT</h2>
	<p>Innan vi börjar skapa och visa fönster behöver vi först känna till EDT (Event Dispatch Thread). Detta är en speciell tråd som körs i Java vilket ansvarar för all grafik, t.ex. att rita upp vårt fönster, samt hantera event som musklick och knapptryckningar.</p>

	<p>Swing komponenter är nämligen inte trådsäkra, detta menas med att de endast bör hanteras av en tråd - dvs EDT. Genom att medvetet eller omedvetet arbeta med Swing-komponenter ifrån flera trådar riskerar vi att skapa grafik-buggar eller i värsta fall programkrasch. Se gärna <a href="http://docs.oracle.com/javase/7/docs/api/javax/swing/package-summary.html#threading">Swing's Threading Policy</a></p>

	<p>Men, tänk på att inte lägga för tunga operationer på EDT. Att räkna ut stora primtal eller använda sig av filer/databaser/nätverkskommunikation etc. passar sig inte på EDT. Långsamma operationer leder till att EDT får mindre tid till sina egna sysslor, vilket gör vårt GUI/applikation oresponsivt. För detta passar det bättre att skapa en worker-tråd som vi kommer till senare.</p>




<h2>Skapa och initiera ett tomt fönster</h2>
	<p>I Swing skapar vi ett fönster genom att instansera klassen JFrame och ställa in synligheten för denna via setVisible(true). Som vi konstaterade innan bör vi dock instansera detta objekt på EDT - men hur? <a href="http://docs.oracle.com/javase/7/docs/api/javax/swing/SwingUtilities.html">SwingUtilities</a> erbjuder oss två metoder <strong>invokeAndWait</strong> samt <strong>invokeLater</strong>. Båda tar ett Runnable objekt som parameter, detta exekveras sedan under EDT. Som du kanske gissat är skillnaden mellan dessa två metoder att invokeAndWait blockar tills EDT har slutfört exekveringen.</p>
	
	<p>Värt att veta är att alla schemalagda körningar via invokeLater alltid körs i den ordning de hamna på kön. Dvs ett senare anrop till invokeLater kan aldrig startas innan samtliga tidigare kö-lagda events bearbetats.</p>

	<p>Nog om teori! Här är ett praktiskt exempel på hur vi skapar upp ett tomt fönster:</p>
	<?php sourceFile( 'empty/MyGUI.java' ); ?>

	<p>Många väljer att låta huvudklassen för applikationen ärva ifrån JFrame. Jag anser dock det vara bättre praxis att endast ärva ifrån klasser när man måste ändra dess funktionalitet/överlagra metoder. Eftersom vi inte vill ändra hur JFrame fungerar deklarerar jag där med hellre denna som en final-instansvariabel (dvs komposition i stället för arv), men detta är en smaksak - båda alternativen fungerar lika bra i praktiken!</p>

	<p>Det vi gör ovan är att skapa en anonym Runnable-klass vars enda uppgift är att skapa och visa MyGUI. Detta lägger vi sedan på EDT's "att göra lista" via metoden invokeLater. Vi vet alltså inte när MyGUI kommer att existera ifrån vår main-tråd, bara att EDT kommer utföra det. invokeLater returnerar direkt och vår main-tråd dör, men detta hindrar inte vår applikation att fortsätta köras. När vi anropar invokeLater eller när vi ställer in en JFrame att vara synlig startas EDT automatiskt, och så länge EDT körs kommer vår applikation att köras.</p>

	<p>Men vänta nu! Om EDT startas när vi visar en JFrame, varför kan vi inte instansera alla Swing komponenter i vår main-tråd och bara anropa setVisible sist? Det är korrekt, vi skulle kunna göra detta för simpla GUI applikationer - men det är inget som rekommenderas, och anses vara dålig praxis. Bland annat blir det lättare att råka använda Swing komponenter ifrån fel tråd, eller anropa setVisible innan vi initierat alla komponenter.</p>

	<p>Vi ser till att vår applikation/EDT avslutas direkt när vi stänger vår JFrame genom att sätta setDefaultCloseOperation till EXIT_ON_CLOSE, skulle vi missa göra detta kommer applikationen fortsättas köras i bakgrunden. Ett alternativ till detta skulle vara DISPOSE_ON_CLOSE vilket ser till att applikationen avslutas endast om det inte finns fler initierade fönster.</p>




<h2>Tunga operationer utanför EDT</h2>

	<p>Låt oss bygga vidare på MyGUI exemplet ovan - säg att vi vill göra en applikation som hämtar och visar ett slumpat citat via sidan www.iheartquotes.com. Vi går inte in på detalj hur själva nerladdningen går till i vår URLFetcher klass, utan vikten för detta exempel är just att själva nerladdningen inte ska ske på EDT tråden. Vi börjar med ett exempel där vi lägger operationen på vår main-tråd: </p>

	<?php sourceFile( 'quote-main/MyGUI.java' ); ?>

	<p>Det bökiga blir att flytta ut MyGUI referensen till själva main-metoden. Vi måste skapa ett MyGUI objekt först, men INTE initiera Swing-komponenterna. Vi skapar en ny metod init() för detta ändamål. Eftersom konstruktorn inte längre körs ifrån EDT kan vi inte deklarera final-instansvariabler, detta på grund av att vi måste skjuta upp själva initieringen till senare. Vi måste även vara försiktiga med att inte arbeta mot MyGUI objektet direkt ifrån main-tråden, endast ifrån EDT. En smidigare lösning hade varit att starta upp en ny tråd direkt ifrån EDT som utför det tunga arbetet. Det tar oss vidare till SwingWorker klassen!</p>




	<h3>SwingWorker - Citat nerladdare</h3>

		<p>För att förhindra att låsa upp EDT mer än nödvändigt kan vi skapa och köra en ny tråd lätt via <a href="http://docs.oracle.com/javase/7/docs/api/javax/swing/SwingWorker.html">SwingWorker</a>. Man kan se detta mer som klassen Runnable, när vi "startar" en SwingWorker schemalägger vi egentligen denna på någon av de befintliga worker-trådarna. Är alla dessa trådar upptagna läggs denna på kö.</p>

		<p>Låt oss börja simpelt med att implementera en arbetare som enbart överlagrar två SwingWorker-metoder. Vi ärver ifrån template-klassen SwingWorker&lt;T,V&gt; där <strong>T</strong> är den datatyp som vi vill att vår tråd ska returnera efter körning, i detta fall passar String bäst eftersom det är just en sträng vi hämtar ifrån Internet. <strong>V</strong> är den datatyp vi använder för status uppdateringar, något vi kommer till sedan. Vi låter detta bara vara datatypen Void så länge.</p>

		<p>Följande SwingWorker metoder kommer användas:</p>

		<ul>
		<li><code>T doInBackground()</code>
		<p>Denna metod måste överlagras. Metoden anropas sedan av den nyskapade tråden, det är här i vi lägger det tunga arbete vi vill bespara EDT ifrån. Kom ihåg att inte använda några Swing komponenter här ifrån! Vill man kommunicera med Swing komponenter kontinuerligt, som t.ex logga händelser till en textruta, anropar vi publish()-metoden med vår nya status som argument. Vill man i stället bara notera EDT om resultatet efter exekveringen kan vi simpelt bara returnera detta. Returvärdet av doInBackground() kan vi sedan läsa med hjälp av get(), fördelaktigt under done() metoden.</p></li>

		<li><code>void done()</code>
		<p>Denna metod anropas av EDT efter vår tråd avslutat. Om doInBackground() returnerade något kan vi läsa av detta värde med hjälp av get().</p></li>

		<li><code>T get()</code>
		<p>Metoden returnerar samma objekt och datatyp som returnerades av doInBackground. OBS! Metoden blockar om tråden fortfarande körs. Eftersom done() anropas efter trådens avslut kan denna med fördel anropas där ifrån för att hämta resultatet av exekveringen. Metoden kan kasta InterruptedException om tråden som anropade get() avbröts, CancellationException om SwingWorker blivit avbruten, samt ExecutionException om doInBackground kastade ett exeption.</p></li>

		<li><code>void execute()</code>
		<p>Vid anrop till denna metod schemaläggs vår SwingWorker till första lediga worker-tråd. <strong>OBS!</strong> en SwingWorker bara kan köras en gång, vill man utföra samma arbetete igen måste man instansera en ny SwingWorker via new.</p></li>
		</ul>

		<?php sourceFile( 'quote-swing/MyGUI.java' ); ?>

		<p>Detta exempel som ni ser fungerar på samma sätt som det tomma JFrame exemplet. Konstruktorn körs under EDT vilket gör att vi kan deklarera final-instansvariabler. Den stora skillnaden är att en SwingWorker skapas och schemaläggs ifrån show-metoden. Vi kallar vår arbetare för QuoteWorker, vilket deklareras som en nästlad klass. Detta gör att vi får tillgång till huvudklassens instansvariabler, som window och textarea referenserna. Programmet körs i dessa steg:</p>
		<ul>
		<li>Main-tråden schemalägger skapandet och startandet av MyGUI på EDT. Main tråden når sitt slut och dör.</li>
		<li>EDT initierar MyGUI och anropar show() - denna visar vårt fönster och schemalägger en QuoteWorker.</li>
		<li>Vår QuoteWorker går igång och startar upp doInBackground() i en worker-tråd. Detta hämtar ett citat och returnerar detta, eller ett felmeddelande, som en sträng.</li>
		<li>När doInBackground() avslutat anropar EDT done() metoden. I denna läser vi strängen som returnerades ifrån doInBackground() via get() metoden, och visar detta i vår textarea.</li>
		</ul>















	<h3>SwingWorker - IRC Client</h3>
	
		<p>I detta exempel implementerar vi en mycket simpel IRC client. För er som inte känner till IRC står det för "Internet Relay Chat", dvs ett chatt protokoll. Programmet kopplar upp sig mot port "6667" på serven "athena.hevox.net" och hoppar därefter in chatt kanalen "public". Om serven är igång och fler av er testar att köra detta exempel samtidigt kommer ni att kunna skriva till varandra!</p>

<p>Till skillnad ifrån innan kommer vår anslutning till serven vara öppen ända tills antingen serven, användaren eller ett fel stänger anslutningen. Så det räcker inte att bara returnera något när vår SwingWorker avslutat - det skulle menas med att man ser vad folk skrivit först efter man kopplat ned! Vi behöver ett sätt att ifrån en SwingWorker skicka information till EDT kontinuerligt under exekveringen.</p>

<h4>Implementering</h4>

<p>Vi kommer att behöva upprätta en anslutning till serven efter användaren valt ett smeknamn och tryckt på Connect-knappen. Detta kan vi göra genom att implementera IrcConnect. Denna SwingWorker öppnar upp en anslutning till serven och startar SwingWorker klasserna SocketReader och SocketWriter. Dessa två trådar skriver och läser parallellt till vår socket.</p>

<p>Implementeringer sker via följande tre SwingWorker-klasser:</p>

<p>IrcConnect - För att ansluta till serven. Denna fungerar på samma sätt som QuoteWorker.<br>
SocketReader - Tar emot information ifrån serven. Varje rad som tas emot loggas i vårt GUI fönster.<br>
SocketWriter - Skickar information till serven. Varje rad som skickas loggas på samma sätt som i SocketReader.</p>



<p>Vi introducerar ett par nya metoder hos SwingWorker:</p>

<ul>
<li><code>boolean cancel(boolean interrupt)</code>
<p>Sätter statusen för vår tråd till avbruten. Om interrupt flaggan är satt true skickas även ett interrupt till tråden. Detta leder till att blockande anrop som t.ex Thread.sleep() kastar InterruptedException, hur vi hanterar interrupt kan vi läsa om här: http://docs.oracle.com/javase/tutorial/essential/concurrency/interrupt.html<br/>
Att försöka anropa get() på en tråd vilket blivit avbruten leder till att metoden kastar InterruptedException eller CancellationException.
Returnerar true om tråden avbröts, annars false.</p></li>

<li><code>boolean isCancelled()</code>
<p>Denna metod returnerar true om vår tråd är signalerad för nedstängning. Denna bör kontrolleras kontinuerligt i doInBackground()-metoden för att kunna avbryta tråden via cancel()-metoden.</p>
</li>

<li><code>void publish(V... chunks)</code>
<p>Denna metod anropas ifrån doInBackground() om vi vill skicka status-uppdateringar till EDT under den långa exekveringen. EDT tar sedan emot detta via process() och uppdaterar eventuella Swing komponenterna.</p></li>

<li><code>void process( List&lt;V&gt; chunks ) - Överlagras, om publish ovan används.</code>
<p>Här tar vi emot en lista med objekt genererade ifrån publish(). Denna metod anropas av EDT, här kan vi alltså uppdatera våra Swing komponenter som t.ex att byta text på JLabels. Eftersom exekveringen är asynkron mellan trådar är det fullt möjligt att vi anropat publish() flera gånger innan EDT hunnit starta process(). Därför får vi en lista med alla objekt publish() har skapat sedan sist metoden kördes. </p></li>

</ul>

<h4>Exempel</h4>

<p>OBS! Detta är inte en snygg klient-lösning, utan ska enbart ses som en exempel på SwingWorker-trådar och dess samspel mellan varandra. Klienten skulle gott och väl klarat sig med enbart en tråd där inloggning, mottagning och skickandet av meddelanden sker sekventiellt.</p>

<p>Vi tittar närmare på klassen SocketReader, denna använder String som template-variablen <strong>V</strong>. Detta eftersom String passar bäst till publish() och process() metoderna för att skicka chatt-meddelanden.</p>

<?php sourceFileLine( 'IRC/SocketReader.java', 7, 17 ); ?>

<p>En närmare titt på doInBackground() samt process() visar hur man skulle kunna ta emot meddelanden ifrån IRC och presentera det i vår textruta på ett smidigt sätt:</p>

<?php sourceFileLine( 'IRC/SocketReader.java', 19, 67 ); ?>

<p>Vi har en while-loop som kontrollerar att våran tråd inte blivit avbruten, i denna loop försöker vi ta emot en rad ifrån IRC-serven - misslyckas vi försöker vi igen! Om serven har stängt anslutningen returnerar vi detta som vår status, denna kan vi sedan läsa med get() efter tråden avslutat. Vi ser även till att avbryta vår SocketWriter-tråd genom att anropa cancel().</p>

<p>Efter vi tagit emot en sträng ifrån IRC-serven vill vi presentera denna för användaren, vi använder publish för att skicka meddelandet till EDT. Om det skulle vara ett PING meddelande ber vi våran Writer-tråd att skicka svaret för att förhindra att vi blir utloggade!</p>

<p>När vi signalerat EDT om det nya meddelandet anropas metoden process() - i denna kan vi fritt använda våra swing-komponenter och kan således skriva ut meddelandet direkt till vår textruta!</p>

<?php sourceFileLine( 'IRC/SocketReader.java', 69, 86 ); ?>

<p>Att anropa get() på en tråd vilket blivit avbruten resulterar i att InterruptedException eller CancellationException kastas, vi kan därför använda detta för att få fram trådens anledning till avslutet. OBS! Strängen "Gracefully cancelled" kommer med andra ord aldrig att returneras (den enda gången while-loopen avslutas är vid fel eller avbrutning). Skillnaden mellan de två är som sagt att CancellationException kastas om vi försöker anropa get() på en tråd som redan har blivit avbruten, medan InterruptedException kastas om tråden avbryts under get() anropet.</p>


<h1>Referenser</h1>
<a href="http://docs.oracle.com/javase/7/docs/api/javax/swing/SwingWorker.html">SwingWorker</a><br/>
<a href="http://docs.oracle.com/javase/7/docs/api/javax/swing/SwingUtilities.html">SwingUtilities</a><br/>
<a href="http://docs.oracle.com/javase/7/docs/api/javax/swing/JFrame.html">JFrame</a><br/>
<a href="http://docs.oracle.com/javase/7/docs/api/javax/swing/package-summary.html#threading">Swing's Threading Policy</a><br/>
<a href="http://en.wikipedia.org/wiki/Abstract_Window_Toolkit">AWT (Wikipedia)</a><br/>
<a href="http://docs.oracle.com/javase/7/docs/api/java/awt/package-summary.html">AWT (javadoc)</a><br/>

</body>
