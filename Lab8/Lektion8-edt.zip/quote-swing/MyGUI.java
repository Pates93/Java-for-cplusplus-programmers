import javax.swing.JFrame;
import javax.swing.SwingUtilities;

import java.net.URL;
import java.util.Scanner;
import java.io.IOException;
import java.io.InputStream;
import javax.swing.JTextArea;
import javax.swing.SwingWorker;

public class MyGUI {
	private final JFrame window;
	private final JTextArea textarea;
	
	public MyGUI(String[] args){
		// Initiera vårt fönster
		window = new JFrame("My First GUI Window");
		// Avsluta vår applikation om vi stänger fönstret
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// Skapa en textarea, och be denna bryta långa rader per ord.
		textarea = new JTextArea();
		textarea.setLineWrap(true);
		textarea.setWrapStyleWord(true);
		textarea.setEditable(false);
		textarea.setText("Laddar citat...");
		
		// Lägg till vår textarea i mitten av vår JFrame
		window.add( textarea );
		 
		// Ställ in standard dimension för vårt fönster
		window.setSize(500,200);
	}
	
	public void show(){
		// Placera fönstret i mitten på skärmen
		window.setLocationRelativeTo(null);
		// Gör vårt fönster synligt
		window.setVisible(true);
		
		// Skapa en arbetare och schemalägg denna för exekvering
		QuoteWorker qw = new QuoteWorker();
		qw.execute();
	}
	
	public class QuoteWorker extends SwingWorker<String,Void>{
		@Override
		protected String doInBackground() {
			// Detta utförs i en ny tråd, detta är INTE EDT!
			
			// Hämta innehållet ifrån hemsidan och returnera som en sträng.
			URLFetcher urlf = new URLFetcher();
			return urlf.get("http://www.iheartquotes.com/api/v1/random");
		}
		
		@Override
		protected void done() {
			// Detta körs på EDT, arbeta med Swing-komponenter här.
			// Kom ihåg att inte göra allt för långa operationer här!
			
			// Hämta texten ifrån doInBackground, eller ett felmeddelande
			String content = "";
			try{
				content = get();
			}catch( Exception e ){
				content = "Error: "+e.toString();
			}
			
			// Visa texten i vår GUI och anpassa fönstret till texten
			textarea.setText( content );
			window.pack();
		}
	}
	
	public static void main(final String[] args) {
		// Detta är vår main-tråd och startpunkt. Be EDT att
		// initiera och visa vårt fönster.
		SwingUtilities.invokeLater(new Runnable() {
			public void run(){
				// Detta kommer exekveras under EDT. Från och med
				// detta kan vi fritt använda oss av Swing!
				final MyGUI gui = new MyGUI(args);
				gui.show();
			}
		});
	}
}
