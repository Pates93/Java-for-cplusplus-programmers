import javax.swing.JFrame;
import javax.swing.SwingUtilities;


import javax.swing.JTextArea;

public class MyGUI {
	private JFrame window;
	private JTextArea textarea;
	
	public void init(String[] args){
		// Initiera vårt fönster
		window = new JFrame("My First GUI Window");
		// Avsluta vår applikation om vi stänger fönstret
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// Skapa en textarea, och be denna bryta långa rader per ord.
		textarea = new JTextArea();
		textarea.setLineWrap(true);
		textarea.setWrapStyleWord(true);
		textarea.setEditable(false);
		textarea.setText("Laddar citat...");
		
		// Lägg till vår textarea i mitten av vår JFrame
		window.add( textarea );
		 
		// Ställ in standard dimension för vårt fönster
		window.setSize(500,200);
	}
	
	public void show(){
		// Placera fönstret i mitten på skärmen
		window.setLocationRelativeTo(null);
		// Gör vårt fönster synligt
		window.setVisible(true);
	}
	
	public static void main(final String[] args) {
		// Detta är vår main-tråd och startpunkt. Be EDT att
		// initiera och visa vårt fönster.
		final MyGUI gui = new MyGUI();
		SwingUtilities.invokeLater(new Runnable() {
			public void run(){
				// Detta kommer exekveras under EDT. Från och med
				// detta kan vi fritt använda oss av Swing!
				gui.init(args);
				gui.show();
			}
		});

		// Hämta innehållet ifrån hemsidan och spara som en sträng.
		URLFetcher urlf = new URLFetcher();
		final String content = urlf.get("http://www.iheartquotes.com/api/v1/random");
		
		// Visa innehållet i GUI-fönstret
		SwingUtilities.invokeLater(new Runnable() {
			public void run(){
				// Be EDT att ställa in texten och anpassa fönstrets storlek
				gui.textarea.setText(content);
				gui.window.pack();
			}
		});
	}
}
