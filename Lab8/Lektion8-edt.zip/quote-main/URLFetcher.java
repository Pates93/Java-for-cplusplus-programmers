import java.net.URL;
import java.util.Scanner;
import java.io.IOException;
import java.io.InputStream;

public class URLFetcher {
	private boolean error = false;
	
	// Returnera inehåll eller felmeddelande
	public String get( final String url ){
		error = false;
		Scanner s = null;
		InputStream webis = null;
		
		try{
			webis = new URL(url).openStream();
			s = new Scanner(webis).useDelimiter("\\A");
			if( s.hasNext() )
				return s.next().replace("&quot;","\"");
			return "";
			
		}catch( Exception e ){
			error = true;
			return e.toString();
			
		}finally{
			// Frigör vår Scanner
			if( s != null )
				s.close();
			
			// Försök stänga anslutningen, ignorera fel
			if( webis != null ){
				try{
					webis.close();
				}catch( Exception e ){ }
			}
		}
	}
	
	// Returnerar true om senare get misslyckades.
	public boolean checkErr(){
		return error;
	}
}
