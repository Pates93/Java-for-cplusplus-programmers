import javax.swing.JFrame;
import javax.swing.SwingUtilities;
public class MyGUI {
	private final JFrame window;
	
	public MyGUI(String[] args){
		// Initiera vår fönster
		window = new JFrame("My First GUI Window");
		// Avsluta vår applikation om vi stänger fönstret
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		// Ställ in dimension för vårt fönster
		window.setSize(400, 200);
	}
	
	public void show(){
		// Placera fönstret i mitten på skärmen
		window.setLocationRelativeTo(null);
		// Gör vårt fönster synligt
		window.setVisible(true);
	}
	
	public static void main(final String[] args) {
		// Detta är våran main-tråd och startpunkt. Be EDT att
		// skapa och visa vårt fönster.
		SwingUtilities.invokeLater(new Runnable() {
			public void run(){
				// Detta kommer exekveras under EDT. Från och med
				// detta kan vi fritt använda oss av Swing!
				MyGUI gui = new MyGUI(args);
				gui.show();
			}
		});
	}
}
