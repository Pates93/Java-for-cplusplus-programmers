import java.util.concurrent.*;
import java.io.*;
import java.net.*;
import javax.swing.*;
import java.util.List;

public class SocketWriter extends SwingWorker<String,String> {
	private final BlockingQueue<String> queue;
	private PrintWriter out = null;
	private final Socket s;
	private final MyGUI gui;
	
	public SocketWriter(MyGUI gui, Socket s){
		this.gui = gui;
		this.s = s;
		queue = new LinkedBlockingQueue<String>();
	}
	
	public void writeLine(String line){
		// Detta är en trådsäker metod, alla trådar kan anropa
		// add på en BlockingQueue utan problem.
		queue.add(line);
	}
	
	@Override
	protected String doInBackground() {
		try{
			// Skapa vår dataström
			out = new PrintWriter( s.getOutputStream(), true );
			// Så länge ingen anropat cancel...
			while( ! isCancelled() ){
				// Vänta tills vi har något att skriva till serven
				String line = queue.take();
				// Finns inget att skriva, börja vänta igen
				if( line == null )
					continue;
				// Försök skicka till serven
				out.println(line);
				// Meddela användaren om att vi lyckades skicka meddelandet
				publish("<"+line);
			}
			return "Gracefully cancelled";
		}catch( Exception e ){
			// Fel inträffade vid anslut/skrivning
			return "Error - " + e.getMessage();
		}finally{
			// Försök stänga vår dataström och socket.
			IrcConnect.tryClose( out );
			IrcConnect.tryClose( s );
		}
	}
	
	@Override
	protected void process( List<String> chunks ){
		// Detta körs på EDT, arbeta med Swing-komponenter här.
		// Kom ihåg att inte göra allt för långa operationer här!
		// Ta emot linjerna vi skickade till serven, skriv ut dem i vår text ruta
		for( String line : chunks ){
			gui.printText( line );
		}
	}
	
	@Override
	protected void done() {
		// Detta körs på EDT.
		
		// Hämta statusen, ignorera fel.
		String status = "Unknown";
		try{
			status = get();
		}catch( InterruptedException | CancellationException e ){
			status = "Cancelled";
		}catch( Exception e ){
			status = e.toString();
		}
		// Skriv ut information om att tråden avslutades och ställ in knapparna.
		gui.printText( "SocketWriter disconnected: " + status );
		gui.setWriter( null );
		gui.setConnected( gui.isConnected() );
	}
}
