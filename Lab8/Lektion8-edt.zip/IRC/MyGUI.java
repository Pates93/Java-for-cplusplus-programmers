import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.util.concurrent.*;

public class MyGUI {
	private static final String NL = System.lineSeparator();
	private final JFrame window;
	private final JTextArea textarea;
	private final JTextField txtnick;
	private final JTextField txtsend;
	private final JButton btnconnect;
	private final JButton btndisconnect;
	private final JButton btnsend;
	private final String host;
	private final Integer port;
	private IrcConnect ircconnect = null;
	private SocketReader ircreader = null;
	private SocketWriter ircwriter = null;
	
	public MyGUI(String[] args){
		host = "athena.hevox.net";
		port = 6667;
		
		// Initiera vårt fönster
		window = new JFrame("My First GUI Window");
		// Avsluta vår applikation om vi stänger fönstret
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// Skapa textrutorna
		textarea = new JTextArea();
		textarea.setLineWrap(true);
		textarea.setWrapStyleWord(true);
		textarea.setEditable(false);
		textarea.setFont( new Font("Monospaced", Font.PLAIN, 11) );
		textarea.setText("(Not connected)");
		Integer rand = new Random( System.currentTimeMillis() ).nextInt(100000);
		txtnick = new JTextField( "gst"+rand, 10 );
		txtsend = new JTextField("",30);
		
		// Skapa knappar
		btnconnect = new JButton("Connect");
		btndisconnect = new JButton("Disconnect");
		btnsend = new JButton("Send");
		
		// Skapa ActionListener's
		btnconnect.addActionListener( new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Skapa bara en ny anslutning om vi inte redan är anslutna
				if( isConnected() )
					return;
					
				// Avaktivera knapp och textruta
				btnconnect.setEnabled( false );
				txtnick.setEnabled( false );
				
				// Skapa en anslutning till serven!
				textarea.setText("Connecting..."+NL);
				ircconnect = new IrcConnect( MyGUI.this, host, port, txtnick.getText() );
				ircconnect.execute();
			}
		});
		btndisconnect.addActionListener( new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Skicka bara ett meddelande till serven om write-tråden är ansluten
				if( ircwriter != null && ! ircwriter.isDone() ){
					ircwriter.writeLine("QUIT");
					//ircwriter.cancel(false);
					//ircreader.cancel(false);
				}
			}
		});
		btnsend.addActionListener( new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Skicka bara ett meddelande till serven om write-tråden är ansluten
				if( ircwriter != null && ! ircwriter.isDone() ){
					ircwriter.writeLine( "PRIVMSG #public :" + txtsend.getText() );
					txtsend.setText("");
				}
			}
		});
		
		// Ställ in vilka knappar vi kan trycka på
		setConnected( false );
		
		// Lägg till vår textarea i mitten av vår JFrame
		window.add( new JScrollPane( textarea ) );
		
		// Skapa en panel högst upp och lägg till knappar och nickname
		JPanel top = new JPanel();
		window.add( top, BorderLayout.NORTH );
		
		
		top.add( new JLabel("Nickname:") );
		top.add( txtnick );
		top.add( btnconnect );
		top.add( btndisconnect );
		
		// Skapa en panel längst ned och placera en textruta och sänd-knapp
		JPanel bottom = new JPanel();
		window.add( bottom, BorderLayout.SOUTH );
		bottom.add( txtsend );
		bottom.add( btnsend );
		
		// Ställ in standard dimension för vårt fönster
		window.setSize(800,400);
	}
	
	public void show(){
		// Placera fönstret i mitten på skärmen
		window.setLocationRelativeTo(null);
		// Gör vårt fönster synligt
		window.setVisible(true);
	}
	
	public void setConnected(boolean chk){
		// Ställ in enable/disable beroende på om vi är anslutna
		btnconnect.setEnabled( !chk );
		txtnick.setEnabled( !chk );
		btndisconnect.setEnabled( chk );
		btnsend.setEnabled( chk );
		txtsend.setEnabled( chk );
	}
	
	public boolean isConnected(){
		// Returnera false om både write och read trådarna är döda
		if( (ircwriter == null || ircwriter.isDone()) &&
		    (ircreader == null || ircreader.isDone()) )
			return false;
		return true;
	}
	
	public void printText(String line){
		// Skriv ut meddelandet
		textarea.append( line );
		// Radbrytning
		textarea.append( NL );
		// scrolla så långt ner det går
		textarea.setCaretPosition(textarea.getDocument().getLength());
	}
	
	public void setWriter(SocketWriter sw){
		// Sparar en referens till SocketWriter
		ircwriter = sw;
	}

	public void setReader(SocketReader sr){
		// Sparar en referens till SocketReader
		ircreader = sr;
	}
	
	public static void main(final String[] args) {
		// Detta är vår main-tråd och startpunkt. Be EDT att
		// initiera och visa vårt fönster.
		SwingUtilities.invokeLater(new Runnable() {
			public void run(){
				// Detta kommer exekveras under EDT. Från och med
				// detta kan vi fritt använda oss av Swing!
				final MyGUI gui = new MyGUI(args);
				gui.show();
			}
		});
	}
}
