#!/bin/bash
mkdir bin 2>/dev/null
javac -d ./bin IrcConnect.java MyGUI.java SocketWriter.java SocketReader.java
