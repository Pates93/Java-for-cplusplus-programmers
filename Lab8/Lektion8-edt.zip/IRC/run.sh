#!/bin/bash
cd bin
java MyGUI
