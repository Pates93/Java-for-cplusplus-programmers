import java.util.concurrent.*;
import java.io.*;
import java.net.*;
import javax.swing.*;

public class IrcConnect extends SwingWorker<Boolean,Void> {
	private SocketReader sr = null;
	private SocketWriter sw = null;
	private Socket s = null;
	private final Integer port;
	private final String host;
	private final String nick;
	private final MyGUI gui;
	
	public static void tryClose(Closeable ca){
		// Försök inte stänga null referenser.
		if( ca == null )
			return;
		// Försök vårt bästa att stänga objektet
		try{
			ca.close();
		}catch( Exception e ){
			// Misslyckades! Vi gjorde vårt bästa iaf!
		}
	}
	public IrcConnect(MyGUI gui, String host, Integer port, String nick){
		this.gui = gui;
		this.port = port;
		this.host = host;
		// Användarnamn kan aldrig vara mer än 8 tecken.
		if( nick.length() > 8 )
			this.nick = nick.substring(0,9);
		else
			this.nick = nick;
	}
	
	@Override
	protected Boolean doInBackground() {
		// Vi får inte anropa gui/Swing här ifrån
		try{
			// Anslut till serven
			Socket s = new Socket(host,port);
			s.setSoTimeout(30000);
			
			// Skapa läs och skriv trådar, samt starta dessa
			sw = new SocketWriter(gui, s);
			sr = new SocketReader(gui, s,sw);
			sw.execute();
			sr.execute();
			
			// Be vår skriv-tråd skicka loggin informationen
			sw.writeLine("NICK "+nick);
			sw.writeLine("USER JDUser 0 * :John Doe");
			// Vänta lite med att skicka join (måste svara på PING först)
			Thread.sleep(1000);
			sw.writeLine("JOIN :#public");
			
			// Allt lyckades!
			return true;
		}catch( Exception e ){
		
			// Något gick fel, avbryt trådarna
			if( sw != null )
				sw.cancel();
			if( sr != null )
				sw.cancel();
				
			// Stäng socketen, ignorera fel
			if( s != null )
				tryClose( s );
				
			// Städa upp referenser
			sw = null;
			sr = null;
			return false;
		}
	}
	
	@Override
	protected void done() {
		// Försök hämta resultatet ifrån exekveringen
		boolean success = false;
		try{
			success = get();
			// Spara referenserna, dessa är null om vi misslyckades
			gui.setWriter( sw );
			gui.setReader( sr );
		}catch( Exception e ){
			success = false;
		}
		// Skriv ut meddelande om vi lyckades
		if( success )
			gui.printText( "Connected!" );
		else
			gui.printText( "Connection failed!" );
		// Ställ in enable/disable på knappar och textrutor
		gui.setConnected( success );
	}
	
}

