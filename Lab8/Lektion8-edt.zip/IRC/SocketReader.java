import java.util.concurrent.*;
import java.io.*;
import java.net.*;
import javax.swing.*;
import java.util.List;

public class SocketReader extends SwingWorker<String,String> {
	private BufferedReader in = null;
	private final Socket s;
	private final SocketWriter sw;
	private final MyGUI gui;
	
	public SocketReader(MyGUI gui, Socket s, SocketWriter sw){
		this.s = s;
		this.sw = sw;
		this.gui = gui;
	}
	
	@Override
	protected String doInBackground() {
		try{
			// Försök skapa en dataström
			in = new BufferedReader( new InputStreamReader( s.getInputStream() ) );
			
			// Ta emot information ifrån serven om vi inte blivit avbrutna
			String line;
			while( ! isCancelled() ){
				try{
					// Så länge vi har en anslutning...
					if( (line = in.readLine()) == null ){
						sw.cancel(true);
						return "Server closed connection";
					}
				}catch( SocketTimeoutException ste ){
					// Ingen data togs emot innan timeout, försök igen
					continue;
				}
			
				// Skicka data ifrån serven till EDT
				publish(">"+line);
		
				// Svara på PING meddelanden
				if( line.substring(0,4).equalsIgnoreCase("PING") ){
					// Skicka vårt svar till SocketWriter
					line = "PONG"+line.substring(4);
					sw.writeLine(line);
				}
			}
			return "Gracefully cancelled";
		}catch( Exception e ){
			return "Error - " + e.getMessage();
		}finally{
			// Försök stänga vår in-ström och socket, vi ignorerar fel
			IrcConnect.tryClose( in );
			IrcConnect.tryClose( s );
		}
	}
	
	@Override
	protected void process( List<String> chunks ){
		// Detta körs på EDT, arbeta med Swing-komponenter här.
		// Kom ihåg att inte göra allt för långa operationer här!
		// Ta emot linjerna vi fick ifrån serven, skriv ut dem i vår text ruta
		for( String line : chunks ){
			gui.printText( line );
		}
	}
	
	@Override
	protected void done() {
		// Detta körs på EDT.
		
		// Hämta statusen, ignorera fel.
		String status = "Unknown";
		try{
			status = get();
		}catch( InterruptedException | CancellationException e ){
			status = "Cancelled";
		}catch( Exception e ){
			status = e.toString();
		}
		// Skriv ut information om att tråden avslutades och ställ in knapparna.
		gui.printText( "SocketReader disconnected: " + status );
		gui.setReader( null );
		gui.setConnected( gui.isConnected() );
	}
}
