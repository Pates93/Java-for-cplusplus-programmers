package dt062g.lesson2.example2;

/**
* <h1>Argument</h1>
* A program that shows how we use String [] args. The program prints
* the first argument that is specified when we start the program. It
* also writes the total number of arguments.
* <p>
* Start the program by typing:
* <code>java Argument your_argument1 your_argument2</code>
* <p>
* Giving proper comments in your program makes it more
* user friendly and it is assumed as a high quality code.
* 
*
* @author  Robert Jonsson (roberi)
* @version 1.0
* @since   2017-10-26 
*/
public class Argument {
	public static void main(String[] args) {
		// Writes the total number of arguments
		System.out.print("Number of arguments: ");
		System.out.println(args.length);
		
		// Writes the value of the first argument
		System.out.print("Argument 1 = ");
		System.out.println(args[0]);
		
		// Writes the second and third arguments
		System.out.println(args[1]);
		System.out.println(args[2]);
		
		/* Note!! If no argument is specified, we will receive an
		 * error message! How we handle errors, or exceptions as
		 * it is called in Java, comes in a later lesson.
		 */
	}
}