package dt062g.lesson2.example5;

import java.io.*; // File, FileNotFoundException
import java.util.*; // Scanner

/**
* <h1>Input2</h1>
* A program that uses two Scanners to read input from both
* the standard input (keyboard) and from a file.
* <p>
* Giving proper comments in your program makes it more
* user friendly and it is assumed as a high quality code.
*
* @author  Robert Jonsson (roberi)
* @version 1.0
* @since   2017-10-30 
*/
public class ScannerTest {
	
	/* When we use a Scanner to read from a file, a FileNotFoundException
	 * can be thrown (if the file is not found). In the method declaration
	 * of main method we need to throw this type of error away. Normally
	 * we would use a try-catch-block to handle the exception.
	 */
	public static void main(String[] args) throws FileNotFoundException {
		// Create a Scanner to use when we want to read from the keyboard.
		Scanner keyboard = new Scanner(System.in);
		
		// Ask the user how many times to display the file content.
		System.out.print("How many times should the contents of the file be displayed? ");
		int numberOfTimes = keyboard.nextInt();
		
		/* After reading a number we need to clear the remaining
		 * 'new line' char by calling nextLine method.
		 */
		keyboard.nextLine();
		
		// Ask the user for a file name (Myfile.txt).
		System.out.print("Which file to read? ");
		String fileName = keyboard.nextLine();
		
		// Close the Scanner when we are not going to use it anymore.
		keyboard.close();
		
		// To store the total number of lines/rows displayed.
		int lineNumber = 0;
		
		// A for-loop to read the file as many times as the user wanted.
		for (int i = 0; i < numberOfTimes; i++) {
			// Create a Scanner to read from a file
			Scanner file = new Scanner(new File(fileName));
			
			// Keep looping as long as there are more data (rows/lines) to read.
			while(file.hasNext()) {
				lineNumber++;

				// Read the next line in the file and store it in a String.
				String tmp = file.nextLine();

				/* Prints line number followed by the line from the file.
				 * With System.out.format we can apply some formatting on
				 * the output. In this case we want line number always to
				 * be 3 chars long and a 0 (zero) will be used to fill
				 * empty positions.
				 */
				System.out.format("%03d - %s\n", lineNumber, tmp);
			}
			
			// Close the Scanner as soon we are done reading from it
			file.close();
		}
	}
}
