package dt062g.lesson2.example1;

/**
* <h1>FirstApp</h1>
* This application prints some text to the standard output.
* <p>
* Giving proper comments in your program makes it more
* user friendly and it is assumed as a high quality code.
* 
*
* @author  Robert Jonsson (roberi)
* @version 1.0
* @since   2017-10-26 
*/
public class FirstApp {
	public static void main(String[] args) {
		System.out.println("Java!");
	}
}