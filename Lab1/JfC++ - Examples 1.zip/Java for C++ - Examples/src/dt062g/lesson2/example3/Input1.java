package dt062g.lesson2.example3;

// In the IO-package we find the classes IOException and BufferedReader
import java.io.*;

/**
* <h1>Input1</h1>
* A program that uses a BufferedReader to read input from
* the standard input (keyboard).
* <p>
* Giving proper comments in your program makes it more
* user friendly and it is assumed as a high quality code.
* 
*
* @author  Robert Jonsson (roberi)
* @version 1.0
* @since   2017-10-26 
*/
public class Input1 {
	
	/* In the main method, we will delete any IO errors that 
	 * BufferedReaders readLine method can generate. We do this
	 * by writing throws IOException in the method declaration.
	 * More about exception handling comes in a later lesson.	 * 
	 */
	public static void main(String[] args) throws IOException {
		/* Declares two variables of the type String. When we read
		 * from the keyboard, it is a string that the readLine
		 * method returns.
		 */
		String firstName;
		String lastName;
		
		/* Creates a object (called input) that we use when we want
		 * to read from the keyboard.
		 */
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		
		/* We can now use the object input when we want to read from
		 * the keyboard by calling the readLine method. This method
		 * returns all text until we press enter.
		 */
		
		/* Ask for the first name and store it as firstName
		 * Note! I do not use the println method because I
		 * want the users input to be on the same line.
		 */
		System.out.print("Enter your first name... ");
		firstName = input.readLine();
		
		// Ask for the last name and store it as lastName
		System.out.print("Enter your last name.... ");
		lastName = input.readLine();
		
		// Prints the users full name to standard out
		System.out.println("\nYour name is " + firstName + " " + lastName + "!");
	}
}
