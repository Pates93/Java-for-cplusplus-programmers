package dt062g.lesson2.example7;

/**
* <h1>Equals</h1>
* A program that tests strings for equality.
* <p>
* Giving proper comments in your program makes it more
* user friendly and it is assumed as a high quality code.
* 
*
* @author  Robert Jonsson (roberi)
* @version 1.0
* @since   2017-10-31 
*/
public class Equals {
	
	public static void main(String[] args) {
		// Declare some strings to test for equality.
		String java = "java";
		String javA = "javA";
		String cPlusPlus1 = "C++";
		String cPlusPlus2 = new String("C++");
		String cPlusPlus3 = "C++";
		
		// Comparison 1
		boolean comparison1 = java.equals("java");
		System.out.println(java + " equals " + "java" + " = " + comparison1);
				
		// Comparison 2
		boolean comparison2 = java.equals(javA);
		System.out.println(java + " equals " + javA + " = " + comparison2);
		
		// Comparison 3
		boolean comparison3 = java.equalsIgnoreCase(javA);
		System.out.println(java + " equalsIgnoreCase " + javA + " = " + comparison3);
		
		// Comparison 4
		boolean comparison4 = cPlusPlus1.equals(cPlusPlus2);
		System.out.println(cPlusPlus1 + " equals " + cPlusPlus2 + " = " + comparison4);
		
		// Comparison 5 (== compares if the two strings refer to the same String object)
		boolean comparison5 = cPlusPlus1 == cPlusPlus2;
		System.out.println(cPlusPlus1 + " == " + cPlusPlus2 + " = " + comparison5);
		
		// Comparison 6
		boolean comparison6 = cPlusPlus1 == cPlusPlus3;
		System.out.println(cPlusPlus1 + " == " + cPlusPlus3 + " = " + comparison6);		
	}
}
