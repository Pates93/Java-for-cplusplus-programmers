package dt062g.lesson2.example6;

// In the swing-package we find classes for Dialogs
import javax.swing.*;

/**
* <h1>Input3</h1>
* A program that uses a JOptionPane to read input from,
* and displaying information to, the user.
* <p>
* Giving proper comments in your program makes it more
* user friendly and it is assumed as a high quality code.
* 
*
* @author  Robert Jonsson (roberi)
* @version 1.0
* @since   2017-10-30 
*/
public class Input3 {
	
	/* When we use JOptionPane we do not need to throw a
	 * IOException in the method declaration.
	 */
	public static void main(String[] args) {
		/* Use JOptionPane to display input dialogs. Store the returned values
		 * in two String-objects.
		 */
		String firstName = JOptionPane.showInputDialog("Enter your first name!");
		String lastName = JOptionPane.showInputDialog("Enter your last name!");
		
		// Create a new String by adding firstName and lastName.
		String output = "Your name is " + firstName + " " + lastName + "!";
		
		/* Show a message to the user by calling showMessageDialog in
		 * JOptionPane. The method takes two arguments. The first is
		 * the parent GUI-object for the dialog. null means no parent 
		 * and the dialog is centered on the screen. The second argument
		 * is the message to display.
		 */
		JOptionPane.showMessageDialog(null, output);
	}
}
