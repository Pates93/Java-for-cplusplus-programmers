package dt062g.lesson2.example4;

// In the util-package we find the class Scanner
import java.util.*;

/**
* <h1>Input2</h1>
* A program that uses a Scanner to read input from
* the standard input (keyboard).
* <p>
* Giving proper comments in your program makes it more
* user friendly and it is assumed as a high quality code.
* 
*
* @author  Robert Jonsson (roberi)
* @version 1.0
* @since   2017-10-26 
*/
public class Input2 {
	
	/* When we use a Scanner we do not need to throw a
	 * IOException in the method declaration.
	 */
	public static void main(String[] args) {
		/* Declares two variables of the type String. When we read
		 * from the Scanner, it is a string that the nextLine
		 * method returns.
		 */
		String firstName;
		String lastName;
		
		/* Creates a Scanner-object (called input) that we use when we
		 * want to read from the keyboard.
		 */
		Scanner input = new Scanner(System.in);
		
		/* We can now use the object input when we want to read from
		 * the keyboard by calling the nextLine method. This method
		 * returns all text until we press enter.
		 */
		
		/* Ask for the first name and store it as firstName
		 * Note! I do not use the println method because I
		 * want the users input to be on the same line.
		 */
		System.out.print("Enter your first name... ");
		firstName = input.nextLine();
		
		// Ask for the last name and store it as lastName
		System.out.print("Enter your last name.... ");
		lastName = input.nextLine();
		
		// Prints the users full name to standard out
		System.out.println("\nYour name is " + firstName + " " + lastName + "!");
		
		// Close the Scanner when we are not going to use it anymore
		// This will also close System.in.
		input.close();
	}
}
